const USER_STATUS = {

}

const ROLE_TYPE = {

}

const ARTICLE_HOTPOINT_TYEP = {
	"normal": "普通",
	"recommend": "推荐",
	"hot": "热门",
	"top": "置顶"
}
const HOTPOINT_STATUS = {
	"normal": "普通",
	"remove": "移除",
}

module.exports = {
	USER_STATUS,
	ROLE_TYPE,
	ARTICLE_HOTPOINT_TYEP,
	HOTPOINT_STATUS
}