//连接数据库信息
module.exports = {
	mysql: {
		host: "localhost",
		user: "root",
		password: "123456", //填写自己的数据库密码
		database: "kite_blog", //填写自己的数据库名
		port: 3306 //数据库运行对应的端口
	}
}