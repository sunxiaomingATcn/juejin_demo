const getters = {
	visitedViews: state => state.tagsView.visitedViews,
	// routerList: state => state.permission.routerList,
}

export default getters