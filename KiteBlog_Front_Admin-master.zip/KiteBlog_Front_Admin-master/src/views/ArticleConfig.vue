<template>
  <div class="container">artcileConfig</div>
</template>

<script>
export default {
  name: "AtricleConfig",
  data() {
    return {};
  },
};
</script>

<style lang="less" scoped>
</style>